<div class="room-connector" id="delRCConfirm">
	<div class="room-connector__overlay" data-room-connector-remove-cancel></div>

	<div class="room-connector__box">
		<label>Are you sure you want to delete this connector?</label>
		<div class="room-connector__buttons">
			<button class="btn btn-primary small" data-room-connector-remove-cancel>No</button>
			<button class="btn btn-primary small green" data-room-connector-remove-save>Yes</button>
		</div>
	</div>
</div>