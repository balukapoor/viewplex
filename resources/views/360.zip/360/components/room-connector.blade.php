<div class="room-connector">

	<div class="room-connector__overlay" data-room-connector-cancel></div>

	<div class="room-connector__box">

		<label>Choose a room to link to:</label>
		<select data-room-connector-choices></select>

		<div class="room-connector__buttons">
			<button class="btn btn-primary small" data-room-connector-cancel>Cancel</button>
			<button class="btn btn-primary small green" data-room-connector-save>Done</button>
		</div>
	</div>


</div>