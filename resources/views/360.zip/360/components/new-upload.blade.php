<div class="upload-tool">

	<div class="upload-tool__overlay" data-upload-tool-cancel></div>

	<div class="upload-tool__box">

		<label>Choose your 360 image:</label>
		<input data-file-input type="file">

		<div class="upload-tool__buttons">
			<button class="btn btn-primary small" data-upload-tool-cancel>Cancel</button>
			<button class="btn btn-primary small green" data-upload-tool-save>Done</button>
		</div>
	</div>


</div>